sudo docker exec -it ESGI_PYTHON sh -c "cd /srv/python; sh" 
